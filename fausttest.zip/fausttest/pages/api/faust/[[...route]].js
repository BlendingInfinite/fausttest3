import "../../faust.config"; // Adjust path as necessary

export { apiRouter as default } from "@faustwp/core";
